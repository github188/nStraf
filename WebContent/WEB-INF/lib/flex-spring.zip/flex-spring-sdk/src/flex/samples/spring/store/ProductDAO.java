package flex.samples.spring.store;

import java.util.Collection;
import org.springframework.dao.DataAccessException;

public interface ProductDAO {

	public Collection findAll() throws DataAccessException ;
	
	public void createProduct(Product product) throws DataAccessException ;
	
	public void updateProduct(Product product) throws DataAccessException ;
	
	public void deleteProduct(Product product) throws DataAccessException ;
	
}