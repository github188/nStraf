package flex.samples.spring.store;

import java.util.List;
import java.util.Collection;

import flex.data.assemblers.AbstractAssembler;

public class ProductAssembler extends AbstractAssembler {

	private ProductDAO productDAO;
	
	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	public Collection fill(List fillParameters) {
		return productDAO.findAll();
	}

	public void createItem(Object newItem) {
	}

	public void updateItem(Object newVersion, Object prevVersion, List changes) {
		productDAO.updateProduct((Product) newVersion);
	}

	public void deleteItem(Object prevVersion) {
	}

}