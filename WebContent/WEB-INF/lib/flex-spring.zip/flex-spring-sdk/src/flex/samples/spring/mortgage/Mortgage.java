package flex.samples.spring.mortgage;

public class Mortgage {

	RateFinder rateFinder;
	
	public void setRateFinder(RateFinder rateFinder) {
		this.rateFinder = rateFinder;
	}
	
	public double calculate(double amount) {
		int term = 360; // 30 years
		double rate = rateFinder.findRate();
		return (amount*(rate/12)) / (1 - 1 /Math.pow((1 + rate/12), term));		
	}
	
}