package flex.samples.spring.mortgage;

public interface RateFinder {
	
	public double findRate();

}
