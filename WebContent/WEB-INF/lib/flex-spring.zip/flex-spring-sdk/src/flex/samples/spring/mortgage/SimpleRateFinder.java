package flex.samples.spring.mortgage;

public class SimpleRateFinder implements RateFinder {

	public double findRate() {
		return 0.05;
	}

}
